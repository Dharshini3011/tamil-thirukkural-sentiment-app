import pandas as pd

data = [
    # ---------- NEGATIVE ----------
    ["நான் தேர்வில் தோல்வியடைந்தேன்", "negative", "அல்லல்செய் காலத்தும் அச்சமின்றித் துள்ளுதல் துன்பம் தரும்", "Fearless action at the wrong time brings sorrow", "failure,confidence"],
    ["நான் மதிப்பெண்கள் குறைவாக பெற்றேன்", "negative", "அறிவும் கல்வியும் ஆதாரமாயின், அல்லவை தம்மை வெல்ல முடியாது", "Knowledge overcomes obstacles", "education,motivation"],
    ["நான் என் நண்பனை இழந்தேன்", "negative", "துயரத்துள் தோழன் துணைநிலை இனிது", "A friend in sorrow is a true support", "sorrow,friendship"],
    ["எனக்கு வேலைவாய்ப்பு கிடைக்கவில்லை", "negative", "உழைவை நம்பிக் கிடந்துழி வாழ்வு", "Effortful life faces setbacks", "job-failure,struggle"],
    ["நான் முயன்றும் எதுவும் நடக்கவில்லை", "negative", "முயற்சி இருந்தால் முடியாதது இல்லை", "Nothing is impossible with effort", "effort,struggle"],
    ["எனக்கு மனஅழுத்தம் அதிகமாக உள்ளது", "negative", "மனநலம் உடையவர்க்கு உலகம் அகம் போலே", "Strong mind feels at home", "mental-health,resilience"],
    ["நான் நம்பிக்கையற்றவராக இருக்கிறேன்", "negative", "துன்பம் வரினும் துணிந்து நிற்கவேண்டும்", "Stand strong amidst sorrow", "motivation,self-belief"],
    ["நான் நண்பர்களிடம் தள்ளப்படுகிறேன்", "negative", "நட்பிற்கும் துணையாக நட்பு", "Friendship must support friendship", "isolation,friendship"],
    ["என் முயற்சிகள் தோல்வியடைந்தன", "negative", "அருமை முயல்வார்க்கு வெற்றி வருந்தாது", "Great efforts never go unrewarded", "struggle,effort"],
    ["நான் என்னை இழந்துவிட்டேன்", "negative", "தான்சிறந்த அறம் உடையான் தான் வாழும்", "Virtue leads to self-realization", "identity,depression"],
    ["எனக்கு உடல்நலம் சரியில்லை", "negative", "உடம்போடு உயிரும் உயிரோடு உணவும்", "Health is life’s foundation", "health,illness"],
    ["நான் பல தடைகளை சந்தித்தேன்", "negative", "தோல்விக்கு பின்னும் முயற்சி சிறந்தது", "Failure should lead to more effort", "barriers,hope"],
    ["நான் தவறு செய்துவிட்டேன்", "negative", "தவறு உணர்தல் தக்க அறம்", "Admitting faults is virtue", "mistake,learning"],
    ["நான் பயமடைகிறேன்", "negative", "அச்சம் தவிர்தல் அறிவுடையான் பண்பு", "Courage is the sign of wisdom", "fear,wisdom"],
    ["நான் யாரிடமும் பேச விரும்பவில்லை", "negative", "மௌனம் நல்லது பகைவரிடம்", "Silence is best among enemies", "silence,emotion"],

    # ---------- POSITIVE ----------
    ["நான் தேர்வில் சிறந்த மதிப்பெண்கள் பெற்றேன்", "positive", "கற்க கசடறக் கற்பவை கற்றபின் நடக்க தவறாதார் கல்வி", "Learn thoroughly and act accordingly", "education,success"],
    ["நான் கடுமையாக உழைத்தேன்", "positive", "திறன் வாய்ந்தார் செய்வது உழைப்பு", "Capable people work hard", "hard-work"],
    ["எனக்கு வேலைவாய்ப்பு கிடைத்தது", "positive", "உழவின் நலன்கள் உலகம் அனுபவிக்கும்", "Hard work benefits the world", "job,success"],
    ["என் முயற்சி வெற்றியாகியுள்ளது", "positive", "வினைவு உடைத்து முயல்வதே சிறந்தது", "Purposeful action is best", "success,effort"],
    ["நான் என் குடும்பத்தை மகிழ்ச்சியாக வைத்தேன்", "positive", "அன்பும் அறனும் உடைத்தாயின் இல்வாழ்க்கை இன்பமும் இயல்பும் அது", "Love and virtue make home happy", "family,happiness"],
    ["நான் ஒரு புதிய விஷயத்தை கற்றுக்கொண்டேன்", "positive", "கல்வி கருதிய எல்லாம் பயக்கும்", "Knowledge leads to results", "learning,skill"],
    ["நான் மற்றவருக்கு உதவினேன்", "positive", "உதவாமல் வாழும் வாழ்க்கை வீண்", "Life without helping is empty", "helping,kindness"],
    ["நான் நண்பர்களுடன் நேரத்தை செலவிட்டேன்", "positive", "நட்புக்கான நேரம் மகிழ்ச்சிக்கான தருணம்", "Friendship time is joy time", "friendship,happiness"],
    ["நான் புத்தகம் எழுதத் தொடங்கினேன்", "positive", "அறிவு பரப்புவதே உயர்ந்த செயல்", "Sharing knowledge is noble", "writing,creativity"],
    ["நான் தினசரி நடைப்பயிற்சி செய்கிறேன்", "positive", "உடல்நலம் வாழ்வின் அடிப்படை", "Health is the foundation of life", "health,habit"],
    ["நான் என் சொந்த நோக்கத்தை அடைந்தேன்", "positive", "நோக்குடன் வாழ்வதே வாழ்க்கை", "Life is meaningful with purpose", "purpose,self"],
    ["நான் தமிழைப் பயின்றேன்", "positive", "தமிழ் வளர்த்தல் தமிழ் மக்கள் பண்பு", "Learning Tamil is cultural pride", "language,learning"],
    ["நான் யோகா செய்து மன அமைதி அடைந்தேன்", "positive", "அமைதி மனிதனின் ஆழ்ந்த செல்வம்", "Peace is true wealth", "peace,yoga"],
    ["நான் இயற்கையை ரசித்தேன்", "positive", "இயற்கை நேசித்தல் உயர்ந்த பண்பு", "Loving nature is noble", "nature,mindfulness"],
    ["நான் என் நண்பனை ஊக்கமளித்தேன்", "positive", "ஊக்கம் கொடுப்பது உன்னத செயல்", "Encouraging others is noble", "encouragement,friendship"],

    # ---------- NEUTRAL ----------
    ["நான் இன்று பள்ளிக்குச் சென்றேன்", "neutral", "எல்லா அறமும் தலைசிறந்தது கல்வி", "Education is the highest virtue", "education,daily"],
    ["அவர் புத்தகம் வாசிக்கிறார்", "neutral", "நூல் வழி கற்கும் நுண்ணறிவு நீடிக்கும்", "Book learning lasts long", "reading,knowledge"],
    ["நான் இன்று சாதம் சாப்பிட்டேன்", "neutral", "உணவே உயிரின் துணை", "Food supports life", "food,health"],
    ["இன்று வெயில் அதிகம்", "neutral", "வானிலைக்கேற்ப நடக்க வேண்டும்", "Adapt to the weather", "climate,neutral"],
    ["நான் வீட்டில் இருக்கிறேன்", "neutral", "இல்லமோர் இன்பம் பயக்கும்", "Home gives joy", "home,neutral"],
    ["நேற்று மழை பெய்தது", "neutral", "பொழிந்த மழை பயன் தரும்", "Rain brings benefit", "rain,nature"],
    ["அவர் வேலைக்கு சென்றார்", "neutral", "வினை செய்க காலம் அறிந்து செயல்", "Act at the right time", "routine,neutral"],
    ["நான் புத்தக கடைக்கு சென்றேன்", "neutral", "நூல் விற்பனை அறிவு பரப்பு", "Bookstores spread wisdom", "neutral,books"],
    ["நான் சாமி கோவிலுக்குச் சென்றேன்", "neutral", "பக்தி நெறி மன அமைதி தரும்", "Faith brings peace", "faith,neutral"],
    ["நான் பஸ் ஸ்டாண்டில் காத்திருந்தேன்", "neutral", "காத்திருப்பதும் ஒரு பொறுமை", "Waiting is a form of patience", "waiting,neutral"],
    ["நான் ஒரு சினிமா பார்த்தேன்", "neutral", "களிப்பும் ஓய்வும் வாழ்வின் பகுதி", "Entertainment is part of life", "entertainment,neutral"],
    ["நான் என் பேனா இழந்துவிட்டேன்", "neutral", "சிறிய இழப்புகள் பெரிதல்ல", "Small losses aren’t serious", "daily,neutral"],
    ["நான் காலை ஓட்டம் சென்றேன்", "neutral", "செயற்கை இல்லாத உடற்பயிற்சி நல்லது", "Natural exercise is healthy", "exercise,neutral"],
    ["நான் என் காலணியை தூக்கியேன்", "neutral", "சுத்தம் உடலுக்கு நல்லது", "Cleanliness is good for health", "neutral,cleanliness"],
    ["அவர் ஒரு பாட்டு கேட்டார்", "neutral", "பாடல் மனதிற்கு ஓரமளிக்கும்", "Songs soothe the mind", "neutral,music"]
]

df = pd.DataFrame(data, columns=["sentence", "emotion", "kural_tamil", "kural_english", "tags"])
df.to_csv("enhanced_tamil_sentiment_dataset.csv", index=False, encoding="utf-8-sig")

print(" Enhanced dataset created as 'enhanced_tamil_sentiment_dataset.csv'")
