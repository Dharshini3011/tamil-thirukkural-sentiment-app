import pandas as pd
import joblib

# Load model and dataset
model = joblib.load("tamil_sentiment_model.pkl")
df = pd.read_csv("tamil_sentiment_thirukkural_dataset.csv")

def keyword_override(sentence):
    keywords_negative = ["தோல்வி", "இழந்தேன்", "மனஅழுத்தம்", "மதிப்பெண்கள் குறைவாக", "வேலை இல்லை"]
    keywords_positive = ["வெற்றி", "வாய்ப்பு", "நல்ல மதிப்பெண்கள்", "வெற்றிகரமாக", "கிடைத்தது"]

    for word in keywords_negative:
        if word in sentence:
            return "negative"
    for word in keywords_positive:
        if word in sentence:
            return "positive"
    return None  # Let model decide

def suggest_kural(user_input):
    # Step 1: Check keywords first
    overridden = keyword_override(user_input)

    if overridden:
        predicted_emotion = overridden
        print(f"\n🔍 Detected Emotion (from keywords): {predicted_emotion}")
    else:
        predicted_emotion = model.predict([user_input])[0]
        print(f"\n🔍 Detected Emotion (from model): {predicted_emotion}")

    # Step 2: Find matching kural
    matching = df[df["emotion"] == predicted_emotion]
    if not matching.empty:
        row = matching.sample(1).iloc[0]
        print("\n📜 Suggested Thirukkural:")
        print(f"📝 Tamil   : {row['kural_tamil']}")
        print(f"💬 English : {row['kural_english']}")
    else:
        print("❌ Sorry, no kural found for this emotion.")
# 📥 Input from user
user_input = input("📥 Enter a Tamil sentence: ")
suggest_kural(user_input)
